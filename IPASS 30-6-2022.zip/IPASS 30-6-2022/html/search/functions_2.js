var searchData=
[
  ['start_0',['start',['../classweatherstation.html#a182593416aac3ce8d36a5c14ba6214bb',1,'weatherstation']]]
];
